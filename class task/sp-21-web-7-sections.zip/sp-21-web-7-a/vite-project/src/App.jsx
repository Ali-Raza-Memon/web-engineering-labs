import React from "react";
import "./App.css";

function App() {
  const myVar = { name: "Hamid" };
  return (
    <>
      <h1>This is heading 1 </h1>
      <h2>This is heading 2 </h2>
    </>
  );
}

export default App;
