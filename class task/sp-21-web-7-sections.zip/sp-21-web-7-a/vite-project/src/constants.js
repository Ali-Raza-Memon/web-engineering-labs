export const ShapeTypes = {
  circle: "CIRCLE",
  square: "square",
  rect: "rect",
};
