import React from "react";

export default function Posts() {
  return <div>posts</div>;
}
